# UtsavLink — Cross-State Event Marketplace
### Telangana ↔ Andhra Pradesh

Same ₹30,000. Ultra-quality vendors from across state lines.

---

## Project Structure
```
utsavlink/
├── backend/          # FastAPI + PostgreSQL
│   ├── app/
│   │   ├── api/routes/   # auth, search, vendors, bookings
│   │   ├── core/         # config, security (JWT)
│   │   ├── db/           # SQLAlchemy session
│   │   ├── models/       # DB models (8 tables)
│   │   ├── schemas/      # Pydantic schemas
│   │   ├── services/     # auth, search, booking logic
│   │   └── utils/        # deps (auth middleware)
│   ├── requirements.txt
│   └── .env.example
└── frontend/         # React + Vite + Tailwind
    └── src/
        ├── pages/        # 8 pages
        ├── components/   # Reusable UI components
        ├── hooks/        # useAuth
        ├── store/        # Zustand auth store
        └── utils/        # API client, constants
```

---

## Quick Start

### 1. PostgreSQL Setup
```sql
CREATE DATABASE utsavlink;
CREATE USER postgres WITH PASSWORD 'password';
GRANT ALL PRIVILEGES ON DATABASE utsavlink TO postgres;
```

### 2. Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your DATABASE_URL and keys
uvicorn app.main:app --reload --port 8000
```
Tables auto-created on first run. Visit http://localhost:8000/docs

### 3. Frontend Setup
```bash
cd frontend
npm install
cp .env.example .env
# Edit VITE_API_URL=http://localhost:8000
npm run dev
```
Visit http://localhost:5173

---

## Features
- Phone OTP login (Twilio / dev mode prints OTP)
- Budget-first vendor search with value score algorithm
- Cross-state vendor discovery (TS ↔ AP)
- Travel cost auto-calculator (Haversine formula)
- Bundle detection (vendors from same city share travel)
- Booking flow (3 steps: Date → Details → Pay)
- Razorpay UPI payments with escrow (30% advance)
- Vendor dashboard (accept/decline bookings)
- Availability calendar management
- Review system (quality + value ratings)

---

## API Docs
After running backend: http://localhost:8000/docs

Key endpoints:
- POST /api/v1/auth/send-otp
- POST /api/v1/auth/verify-otp
- GET  /api/v1/search/vendors?budget=30000&category=photography&district=Nalgonda
- GET  /api/v1/search/bundles?categories=photography,decoration&district=Nalgonda&budget=60000
- POST /api/v1/bookings
- POST /api/v1/payments/initiate
- POST /api/v1/reviews

---

## Environment Variables

### Backend (.env)
| Variable | Description |
|---|---|
| DATABASE_URL | PostgreSQL connection string |
| SECRET_KEY | JWT signing key (use long random string) |
| TWILIO_ACCOUNT_SID | For OTP SMS (optional — prints to console in dev) |
| RAZORPAY_KEY_ID | For payments (optional — simulates in dev) |

### Frontend (.env)
| Variable | Description |
|---|---|
| VITE_API_URL | Backend URL (default: http://localhost:8000) |
| VITE_RAZORPAY_KEY | Razorpay public key |

---

Built by Gopi · UtsavLink © 2025
