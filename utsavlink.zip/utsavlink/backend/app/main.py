from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.db.session import engine, Base
import app.models.models  # ensure tables registered
from app.api.routes import auth, search, vendors, bookings

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="UtsavLink API",
    description="Cross-state event vendor marketplace — Telangana ↔ Andhra Pradesh",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL, "http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/v1")
app.include_router(search.router, prefix="/api/v1")
app.include_router(vendors.router, prefix="/api/v1")
app.include_router(bookings.router, prefix="/api/v1")

@app.get("/")
def root(): return {"app": "UtsavLink API", "version": "1.0.0", "docs": "/docs"}

@app.get("/health")
def health(): return {"status": "healthy"}
