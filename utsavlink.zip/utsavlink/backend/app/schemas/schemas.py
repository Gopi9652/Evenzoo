from pydantic import BaseModel, field_validator
from typing import Optional, List
from datetime import date, datetime
from app.models.models import UserRole, StateEnum, CategoryEnum, BookingStatus, PaymentStatus, EventType, LanguagePref

class SendOTPRequest(BaseModel):
    phone: str
    @field_validator("phone")
    @classmethod
    def validate_phone(cls, v):
        v = v.strip().replace(" ","").replace("-","")
        if not v.isdigit() or len(v) != 10:
            raise ValueError("Phone must be 10 digits")
        return v

class VerifyOTPRequest(BaseModel):
    phone: str
    otp: str

class RegisterRequest(BaseModel):
    phone: str
    name: str
    district: str
    state: StateEnum
    role: UserRole = UserRole.customer
    language_pref: LanguagePref = LanguagePref.telugu

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    role: str
    is_new_user: bool

class VendorCreate(BaseModel):
    business_name: str
    category: CategoryEnum
    description: Optional[str] = None
    base_price: int
    willing_to_travel: bool = True
    travel_radius_km: int = 300
    travel_charge_per_km: float = 12.0
    district: str
    state: StateEnum
    lat: Optional[float] = None
    lng: Optional[float] = None
    whatsapp_number: Optional[str] = None
    instagram_handle: Optional[str] = None

class VendorUpdate(BaseModel):
    business_name: Optional[str] = None
    description: Optional[str] = None
    base_price: Optional[int] = None
    willing_to_travel: Optional[bool] = None
    travel_radius_km: Optional[int] = None
    travel_charge_per_km: Optional[float] = None
    whatsapp_number: Optional[str] = None
    instagram_handle: Optional[str] = None

class VendorOut(BaseModel):
    id: str; user_id: str; business_name: str; category: CategoryEnum
    description: Optional[str]; base_price: int; willing_to_travel: bool
    travel_radius_km: int; quality_score: float; value_score: float
    total_events: int; portfolio_urls: List[str]; verified: bool
    district: Optional[str]; state: Optional[StateEnum]
    lat: Optional[float]; lng: Optional[float]
    whatsapp_number: Optional[str]; instagram_handle: Optional[str]
    created_at: datetime
    class Config: from_attributes = True

class VendorSearchResult(BaseModel):
    id: str; business_name: str; category: CategoryEnum
    district: Optional[str]; state: Optional[StateEnum]
    base_price: int; travel_cost: int; total_cost: int
    value_score: float; quality_score: float; avg_rating: Optional[float]
    total_reviews: int; total_events: int; portfolio_urls: List[str]
    verified: bool; willing_to_travel: bool; distance_km: Optional[float]
    class Config: from_attributes = True

class AvailabilitySet(BaseModel):
    date: date
    is_available: bool
    willing_to_travel_on_date: bool = True

class AvailabilityBatch(BaseModel):
    dates: List[AvailabilitySet]

class BookingCreate(BaseModel):
    vendor_id: str; event_date: date; event_type: EventType
    event_location: str; event_start_time: Optional[str] = None
    event_duration_hours: int = 6; special_requests: Optional[str] = None

class BookingOut(BaseModel):
    id: str; customer_id: str; vendor_id: str; event_date: date
    event_type: EventType; event_location: str
    event_start_time: Optional[str]; event_duration_hours: int
    special_requests: Optional[str]; service_amount: int
    travel_amount: int; total_amount: int; advance_amount: int
    status: BookingStatus; payment_status: PaymentStatus; created_at: datetime
    class Config: from_attributes = True

class DeclineRequest(BaseModel):
    reason: str

class PaymentInitiate(BaseModel):
    booking_id: str

class PaymentOrderOut(BaseModel):
    order_id: str; amount: int; currency: str; booking_id: str; razorpay_key: str

class ReviewCreate(BaseModel):
    booking_id: str; rating: float
    quality_rating: Optional[float] = None
    value_rating: Optional[float] = None
    comment: Optional[str] = None

class ReviewOut(BaseModel):
    id: str; booking_id: str; vendor_id: str; rating: float
    quality_rating: Optional[float]; value_rating: Optional[float]
    comment: Optional[str]; created_at: datetime
    class Config: from_attributes = True

class BundleOut(BaseModel):
    vendor1: VendorSearchResult; vendor2: VendorSearchResult
    shared_travel_saving: int; combined_total: int
