import math
from typing import List, Optional
from datetime import date
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.models import VendorProfile, VendorAvailability, Review, CategoryEnum
from app.schemas.schemas import VendorSearchResult, BundleOut

DISTRICT_COORDS = {
    "Hyderabad":(17.385,78.4867),"Nalgonda":(17.0575,79.269),
    "Warangal":(17.9784,79.5941),"Khammam":(17.2473,80.1514),
    "Nizamabad":(18.6726,78.0941),"Karimnagar":(18.4386,79.1288),
    "Rangareddy":(17.2,78.4),"Medak":(18.044,78.2613),
    "Vijayawada":(16.5062,80.648),"Guntur":(16.3067,80.4365),
    "Visakhapatnam":(17.6868,83.2185),"Nellore":(14.4426,79.9865),
    "Kurnool":(15.8281,78.0373),"Tirupati":(13.6288,79.4192),
    "Rajahmundry":(17.0052,81.778),"Kakinada":(16.9891,82.2475),
    "Anantapur":(14.6819,77.6006),"Kadapa":(14.4753,78.8249),
}

def haversine(lat1,lon1,lat2,lon2):
    R=6371; d=math.radians
    a=(math.sin(d(lat2-lat1)/2)**2 +
       math.cos(d(lat1))*math.cos(d(lat2))*math.sin(d(lon2-lon1)/2)**2)
    return R*2*math.atan2(math.sqrt(a),math.sqrt(1-a))

def calc_travel_cost(vendor: VendorProfile, customer_district: str) -> int:
    if not vendor.willing_to_travel or vendor.district == customer_district:
        return 0
    vc = DISTRICT_COORDS.get(vendor.district or "")
    cc = DISTRICT_COORDS.get(customer_district)
    if not vc or not cc: return 2000
    dist = haversine(vc[0],vc[1],cc[0],cc[1])
    if dist > vendor.travel_radius_km: return -1
    cost = int(dist * vendor.travel_charge_per_km)
    if dist > 150: cost += 800
    return cost

def calc_value_score(quality,budget,total_cost,avg_rating,reviews) -> float:
    if total_cost > budget: return 0.0
    q = (quality/10)*100
    pe = ((budget-total_cost)/budget)*100
    rw = min((avg_rating/5)*100,100) if avg_rating else 50
    trust = min(reviews/20,1.0)
    return round(min((q*0.4+pe*0.4+rw*0.2)*(0.7+trust*0.3),100),1)

def search_vendors(db,budget,category,customer_district,event_date,scope="both"):
    q = db.query(VendorProfile).filter(VendorProfile.category==category)
    if scope=="local": q=q.filter(VendorProfile.district==customer_district)
    elif scope=="cross": q=q.filter(VendorProfile.district!=customer_district)
    vendors = q.all(); results = []
    for v in vendors:
        if event_date:
            has_any = db.query(VendorAvailability).filter(VendorAvailability.vendor_id==v.id).count()
            if has_any > 0:
                avail = db.query(VendorAvailability).filter(
                    VendorAvailability.vendor_id==v.id,
                    VendorAvailability.date==event_date,
                    VendorAvailability.is_available==True
                ).first()
                if not avail: continue
        tc = calc_travel_cost(v, customer_district)
        if tc == -1: continue
        total = v.base_price + tc
        if total > budget: continue
        rr = db.query(func.avg(Review.rating),func.count(Review.id)).filter(Review.vendor_id==v.id).first()
        avg_r = float(rr[0]) if rr[0] else None; tot_r = rr[1] or 0
        vc = DISTRICT_COORDS.get(v.district or "")
        cc = DISTRICT_COORDS.get(customer_district)
        dist_km = round(haversine(vc[0],vc[1],cc[0],cc[1]),1) if vc and cc else None
        vs = calc_value_score(v.quality_score,budget,total,avg_r or 0,tot_r)
        results.append(VendorSearchResult(
            id=v.id,business_name=v.business_name,category=v.category,
            district=v.district,state=v.state,base_price=v.base_price,
            travel_cost=tc,total_cost=total,value_score=vs,
            quality_score=v.quality_score,avg_rating=avg_r,total_reviews=tot_r,
            total_events=v.total_events,portfolio_urls=v.portfolio_urls or [],
            verified=v.verified,willing_to_travel=v.willing_to_travel,distance_km=dist_km
        ))
    results.sort(key=lambda x:x.value_score,reverse=True)
    return results

def detect_bundles(db,categories,customer_district,event_date,budget):
    if len(categories) < 2: return []
    all_r = {cat:search_vendors(db,budget,cat,customer_district,event_date) for cat in categories}
    bundles = []; cats = list(all_r.keys())
    for i in range(len(cats)):
        for j in range(i+1,len(cats)):
            for v1 in all_r[cats[i]]:
                for v2 in all_r[cats[j]]:
                    if v1.district==v2.district and v1.district!=customer_district:
                        saving = min(v1.travel_cost,v2.travel_cost)//2
                        if saving > 0:
                            bundles.append(BundleOut(
                                vendor1=v1,vendor2=v2,
                                shared_travel_saving=saving,
                                combined_total=v1.total_cost+v2.total_cost-saving
                            ))
    return bundles[:5]
