from sqlalchemy.orm import Session
from app.models.models import (Booking, VendorProfile, VendorAvailability,
    Payment, BookingStatus, PaymentStatus, User)
from app.schemas.schemas import BookingCreate
from app.services.search_service import calc_travel_cost
from app.core.config import settings

def create_booking(db: Session, customer_id: str, data: BookingCreate) -> Booking:
    vendor = db.query(VendorProfile).filter(VendorProfile.id==data.vendor_id).first()
    if not vendor: raise ValueError("Vendor not found")
    customer = db.query(User).filter(User.id==customer_id).first()
    tc = calc_travel_cost(vendor, customer.district or "")
    if tc == -1: tc = 0
    total = vendor.base_price + tc
    advance = int(total * 0.30)
    b = Booking(
        customer_id=customer_id, vendor_id=data.vendor_id,
        event_date=data.event_date, event_type=data.event_type,
        event_location=data.event_location, event_start_time=data.event_start_time,
        event_duration_hours=data.event_duration_hours,
        special_requests=data.special_requests,
        service_amount=vendor.base_price, travel_amount=tc,
        total_amount=total, advance_amount=advance
    )
    db.add(b); db.commit(); db.refresh(b); return b

def initiate_payment(db: Session, booking_id: str) -> dict:
    b = db.query(Booking).filter(Booking.id==booking_id).first()
    if not b: raise ValueError("Booking not found")
    if settings.RAZORPAY_KEY_ID:
        import razorpay
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        order = client.order.create({"amount":b.advance_amount*100,"currency":"INR","receipt":booking_id})
        order_id = order["id"]
    else:
        order_id = f"order_dev_{booking_id[:8]}"
    p = Payment(booking_id=booking_id, razorpay_order_id=order_id, amount=b.advance_amount)
    db.add(p); db.commit()
    return {"order_id":order_id,"amount":b.advance_amount,"currency":"INR",
            "booking_id":booking_id,"razorpay_key":settings.RAZORPAY_KEY_ID or "rzp_test_demo"}

def confirm_payment(db: Session, order_id: str, payment_id: str, sig: str) -> Booking:
    p = db.query(Payment).filter(Payment.razorpay_order_id==order_id).first()
    if not p: raise ValueError("Payment not found")
    p.razorpay_payment_id = payment_id; p.status = "paid"
    b = db.query(Booking).filter(Booking.id==p.booking_id).first()
    b.payment_status = PaymentStatus.advance_paid
    ex = db.query(VendorAvailability).filter(
        VendorAvailability.vendor_id==b.vendor_id, VendorAvailability.date==b.event_date).first()
    if ex: ex.is_available = False
    else: db.add(VendorAvailability(vendor_id=b.vendor_id,date=b.event_date,is_available=False))
    db.commit(); return b

def vendor_confirm(db, booking_id, vendor_profile_id):
    b = db.query(Booking).filter(Booking.id==booking_id, Booking.vendor_id==vendor_profile_id).first()
    if not b: raise ValueError("Not found")
    b.status = BookingStatus.confirmed; db.commit(); db.refresh(b); return b

def vendor_decline(db, booking_id, vendor_profile_id, reason):
    b = db.query(Booking).filter(Booking.id==booking_id, Booking.vendor_id==vendor_profile_id).first()
    if not b: raise ValueError("Not found")
    b.status = BookingStatus.declined; b.decline_reason = reason
    db.commit(); db.refresh(b); return b

def complete_booking(db, booking_id):
    b = db.query(Booking).filter(Booking.id==booking_id).first()
    if not b: raise ValueError("Not found")
    b.status = BookingStatus.completed; b.payment_status = PaymentStatus.released
    v = db.query(VendorProfile).filter(VendorProfile.id==b.vendor_id).first()
    if v: v.total_events += 1
    db.commit(); db.refresh(b); return b
