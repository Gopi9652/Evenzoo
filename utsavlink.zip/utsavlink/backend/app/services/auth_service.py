import random, string
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from app.models.models import User, OTPStore
from app.core.security import create_access_token
from app.core.config import settings

def generate_otp() -> str:
    return "".join(random.choices(string.digits, k=6))

def send_otp_sms(phone: str, otp: str) -> bool:
    if settings.TWILIO_ACCOUNT_SID:
        try:
            from twilio.rest import Client
            client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
            client.messages.create(
                body=f"Your UtsavLink OTP: {otp}. Valid 10 mins. Do not share.",
                from_=settings.TWILIO_PHONE_NUMBER,
                to=f"+91{phone}"
            )
        except Exception as e:
            print(f"SMS failed: {e}")
    print(f"[DEV] OTP for +91{phone}: {otp}")
    return True

def get_or_create_user(db: Session, phone: str):
    user = db.query(User).filter(User.phone == phone).first()
    if user: return user, False
    user = User(phone=phone)
    db.add(user); db.commit(); db.refresh(user)
    return user, True

def store_otp(db: Session, phone: str, otp: str):
    db.query(OTPStore).filter(OTPStore.phone == phone).update({"is_used": True})
    db.add(OTPStore(phone=phone, otp=otp, expires_at=datetime.utcnow()+timedelta(minutes=10)))
    db.commit()

def verify_otp_code(db: Session, phone: str, otp: str) -> bool:
    rec = db.query(OTPStore).filter(
        OTPStore.phone == phone,
        OTPStore.otp == otp,
        OTPStore.is_used == False,
        OTPStore.expires_at > datetime.utcnow()
    ).first()
    if rec:
        rec.is_used = True; db.commit(); return True
    return False

def build_token(user: User) -> str:
    return create_access_token({"sub": user.id, "role": user.role.value})
