from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date
from app.db.session import get_db
from app.models.models import CategoryEnum
from app.schemas.schemas import VendorSearchResult, BundleOut
from app.services import search_service

router = APIRouter(prefix="/search", tags=["Search"])

@router.get("/vendors", response_model=List[VendorSearchResult])
def search_vendors(
    budget: int = Query(..., gt=0, description="Total budget in rupees"),
    category: CategoryEnum = Query(...),
    district: str = Query(..., description="Customer's district"),
    event_date: Optional[date] = Query(None),
    scope: str = Query("both", description="both | local | cross"),
    db: Session = Depends(get_db)
):
    """Core search: vendors ranked by value score. Travel cost included."""
    return search_service.search_vendors(db, budget, category, district, event_date, scope)

@router.get("/bundles", response_model=List[BundleOut])
def search_bundles(
    budget: int = Query(..., gt=0),
    categories: str = Query(..., description="Comma-separated: photography,decoration"),
    district: str = Query(...),
    event_date: Optional[date] = Query(None),
    db: Session = Depends(get_db)
):
    """Detect vendor pairs from same city to share travel cost."""
    cats = [CategoryEnum(c.strip()) for c in categories.split(",")]
    return search_service.detect_bundles(db, cats, district, event_date, budget)

@router.get("/compare")
def compare_vendors(
    vendor_ids: str = Query(..., description="Comma-separated vendor IDs"),
    budget: int = Query(50000),
    district: str = Query("Hyderabad"),
    db: Session = Depends(get_db)
):
    from app.models.models import VendorProfile, Review
    from sqlalchemy import func
    ids = [v.strip() for v in vendor_ids.split(",")]; results=[]
    for vid in ids:
        v = db.query(VendorProfile).filter(VendorProfile.id==vid).first()
        if not v: continue
        tc = search_service.calc_travel_cost(v, district)
        avg_r = db.query(func.avg(Review.rating)).filter(Review.vendor_id==vid).scalar()
        results.append({"id":v.id,"business_name":v.business_name,"category":v.category,
            "district":v.district,"state":v.state,"base_price":v.base_price,
            "travel_cost":tc if tc!=-1 else 0,
            "total_cost":v.base_price+(tc if tc!=-1 else 0),
            "quality_score":v.quality_score,"value_score":v.value_score,
            "avg_rating":float(avg_r) if avg_r else None,
            "total_events":v.total_events,"portfolio_urls":v.portfolio_urls,"verified":v.verified})
    return results
