from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from app.db.session import get_db
from app.models.models import Booking, User, BookingStatus, Review, VendorProfile
from app.schemas.schemas import (BookingCreate, BookingOut, DeclineRequest,
    ReviewCreate, ReviewOut, PaymentInitiate, PaymentOrderOut)
from app.services import booking_service
from app.utils.deps import get_current_user, get_current_vendor

router = APIRouter(tags=["Bookings & Payments"])

@router.post("/bookings", response_model=BookingOut)
def create_booking(body: BookingCreate, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    try: return booking_service.create_booking(db, current_user.id, body)
    except ValueError as e: raise HTTPException(400, str(e))

@router.get("/bookings/my", response_model=List[BookingOut])
def my_bookings(current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    return db.query(Booking).filter(Booking.customer_id==current_user.id).order_by(Booking.created_at.desc()).all()

@router.get("/bookings/{booking_id}", response_model=BookingOut)
def get_booking(booking_id: str, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    b = db.query(Booking).filter(Booking.id==booking_id).first()
    if not b: raise HTTPException(404, "Not found")
    if b.customer_id != current_user.id:
        if not current_user.vendor_profile or b.vendor_id != current_user.vendor_profile.id:
            raise HTTPException(403, "Unauthorized")
    return b

@router.put("/bookings/{booking_id}/confirm")
def vendor_confirm(booking_id: str, current_user: User=Depends(get_current_vendor), db: Session=Depends(get_db)):
    if not current_user.vendor_profile: raise HTTPException(404, "No vendor profile")
    try:
        b = booking_service.vendor_confirm(db, booking_id, current_user.vendor_profile.id)
        return {"status": b.status, "booking_id": b.id}
    except ValueError as e: raise HTTPException(404, str(e))

@router.put("/bookings/{booking_id}/decline")
def vendor_decline(booking_id: str, body: DeclineRequest, current_user: User=Depends(get_current_vendor), db: Session=Depends(get_db)):
    if not current_user.vendor_profile: raise HTTPException(404, "No vendor profile")
    try:
        b = booking_service.vendor_decline(db, booking_id, current_user.vendor_profile.id, body.reason)
        return {"status": b.status}
    except ValueError as e: raise HTTPException(404, str(e))

@router.put("/bookings/{booking_id}/complete")
def complete_booking(booking_id: str, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    try: b = booking_service.complete_booking(db, booking_id); return {"status": b.status}
    except ValueError as e: raise HTTPException(404, str(e))

@router.get("/vendor/bookings")
def vendor_bookings(current_user: User=Depends(get_current_vendor), db: Session=Depends(get_db)):
    if not current_user.vendor_profile: raise HTTPException(404, "No vendor profile")
    return db.query(Booking).filter(Booking.vendor_id==current_user.vendor_profile.id).order_by(Booking.created_at.desc()).all()

@router.post("/payments/initiate", response_model=PaymentOrderOut)
def initiate_payment(body: PaymentInitiate, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    try: return booking_service.initiate_payment(db, body.booking_id)
    except ValueError as e: raise HTTPException(400, str(e))

@router.post("/payments/verify")
def verify_payment(body: dict, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    try:
        b = booking_service.confirm_payment(db,body.get("razorpay_order_id"),body.get("razorpay_payment_id"),body.get("razorpay_signature",""))
        return {"success": True, "booking_id": b.id, "status": b.status}
    except Exception as e: raise HTTPException(400, str(e))

@router.post("/payments/webhook")
async def webhook(request: Request, db: Session=Depends(get_db)):
    data = await request.json()
    try:
        entity = data.get("payload",{}).get("payment",{}).get("entity",{})
        if entity.get("order_id"):
            booking_service.confirm_payment(db,entity["order_id"],entity.get("id",""),"")
    except: pass
    return {"status": "ok"}

@router.post("/reviews", response_model=ReviewOut)
def create_review(body: ReviewCreate, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    b = db.query(Booking).filter(Booking.id==body.booking_id, Booking.customer_id==current_user.id).first()
    if not b: raise HTTPException(404, "Booking not found")
    if b.status != BookingStatus.completed: raise HTTPException(400, "Can only review completed bookings")
    if db.query(Review).filter(Review.booking_id==body.booking_id).first():
        raise HTTPException(400, "Already reviewed this booking")
    r = Review(booking_id=body.booking_id, vendor_id=b.vendor_id, customer_id=current_user.id,
               rating=body.rating, quality_rating=body.quality_rating,
               value_rating=body.value_rating, comment=body.comment)
    db.add(r)
    avg_q = db.query(func.avg(Review.quality_rating)).filter(Review.vendor_id==b.vendor_id).scalar()
    if avg_q:
        vp = db.query(VendorProfile).filter(VendorProfile.id==b.vendor_id).first()
        if vp: vp.quality_score = float(avg_q) * 2
    db.commit(); db.refresh(r); return r
