from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.schemas.schemas import SendOTPRequest, VerifyOTPRequest, RegisterRequest, TokenResponse
from app.services import auth_service
from app.utils.deps import get_current_user
from app.models.models import User

router = APIRouter(prefix="/auth", tags=["Auth"])

@router.post("/send-otp")
def send_otp(body: SendOTPRequest, db: Session = Depends(get_db)):
    otp = auth_service.generate_otp()
    auth_service.get_or_create_user(db, body.phone)
    auth_service.store_otp(db, body.phone, otp)
    auth_service.send_otp_sms(body.phone, otp)
    return {"message": "OTP sent successfully", "phone": body.phone}

@router.post("/verify-otp", response_model=TokenResponse)
def verify_otp(body: VerifyOTPRequest, db: Session = Depends(get_db)):
    if not auth_service.verify_otp_code(db, body.phone, body.otp):
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")
    user, _ = auth_service.get_or_create_user(db, body.phone)
    token = auth_service.build_token(user)
    return TokenResponse(access_token=token, user_id=user.id,
                         role=user.role.value, is_new_user=user.name is None)

@router.post("/register", response_model=TokenResponse)
def register(body: RegisterRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.phone == body.phone).first()
    if not user: raise HTTPException(status_code=404, detail="Send OTP first")
    user.name=body.name; user.district=body.district
    user.state=body.state; user.role=body.role; user.language_pref=body.language_pref
    db.commit(); db.refresh(user)
    return TokenResponse(access_token=auth_service.build_token(user),
                         user_id=user.id, role=user.role.value, is_new_user=False)

@router.get("/me")
def get_me(current_user: User = Depends(get_current_user)):
    return {"id":current_user.id,"name":current_user.name,"phone":current_user.phone,
            "role":current_user.role,"district":current_user.district,"state":current_user.state,
            "language_pref":current_user.language_pref}
