from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from app.db.session import get_db
from app.models.models import VendorProfile, VendorAvailability, Review, SavedVendor, User
from app.schemas.schemas import VendorCreate, VendorUpdate, VendorOut, AvailabilityBatch, ReviewOut
from app.utils.deps import get_current_user, get_current_vendor

router = APIRouter(prefix="/vendors", tags=["Vendors"])

@router.post("/register", response_model=VendorOut)
def register_vendor(body: VendorCreate, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    if current_user.vendor_profile:
        raise HTTPException(400, "Vendor profile already exists")
    v = VendorProfile(**body.model_dump(), user_id=current_user.id)
    db.add(v); current_user.role = "vendor"; db.commit(); db.refresh(v); return v

@router.get("/me/profile", response_model=VendorOut)
def my_profile(current_user: User=Depends(get_current_vendor), db: Session=Depends(get_db)):
    if not current_user.vendor_profile:
        raise HTTPException(404, "No vendor profile found")
    return current_user.vendor_profile

@router.get("/saved/list")
def list_saved(current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    return [{"vendor_id":s.vendor_id,"saved_at":s.created_at}
            for s in db.query(SavedVendor).filter(SavedVendor.user_id==current_user.id).all()]

@router.get("/{vendor_id}", response_model=VendorOut)
def get_vendor(vendor_id: str, db: Session=Depends(get_db)):
    v = db.query(VendorProfile).filter(VendorProfile.id==vendor_id).first()
    if not v: raise HTTPException(404, "Vendor not found")
    return v

@router.put("/{vendor_id}", response_model=VendorOut)
def update_vendor(vendor_id: str, body: VendorUpdate, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    v = db.query(VendorProfile).filter(VendorProfile.id==vendor_id, VendorProfile.user_id==current_user.id).first()
    if not v: raise HTTPException(404, "Not found or unauthorized")
    for k, val in body.model_dump(exclude_none=True).items(): setattr(v, k, val)
    db.commit(); db.refresh(v); return v

@router.get("/{vendor_id}/availability")
def get_availability(vendor_id: str, month: str=Query(..., description="YYYY-MM"), db: Session=Depends(get_db)):
    yr, mo = map(int, month.split("-"))
    recs = db.query(VendorAvailability).filter(
        VendorAvailability.vendor_id==vendor_id,
        func.extract("year", VendorAvailability.date)==yr,
        func.extract("month", VendorAvailability.date)==mo
    ).all()
    return [{"date":str(r.date),"is_available":r.is_available,"willing_to_travel":r.willing_to_travel_on_date} for r in recs]

@router.post("/{vendor_id}/availability")
def set_availability(vendor_id: str, body: AvailabilityBatch, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    v = db.query(VendorProfile).filter(VendorProfile.id==vendor_id, VendorProfile.user_id==current_user.id).first()
    if not v: raise HTTPException(403, "Unauthorized")
    for item in body.dates:
        ex = db.query(VendorAvailability).filter(VendorAvailability.vendor_id==vendor_id, VendorAvailability.date==item.date).first()
        if ex:
            ex.is_available=item.is_available; ex.willing_to_travel_on_date=item.willing_to_travel_on_date
        else:
            db.add(VendorAvailability(vendor_id=vendor_id, date=item.date,
                is_available=item.is_available, willing_to_travel_on_date=item.willing_to_travel_on_date))
    db.commit(); return {"message": f"Updated {len(body.dates)} records"}

@router.get("/{vendor_id}/reviews", response_model=List[ReviewOut])
def get_reviews(vendor_id: str, page: int=1, per_page: int=10, db: Session=Depends(get_db)):
    return db.query(Review).filter(Review.vendor_id==vendor_id)        .order_by(Review.created_at.desc()).offset((page-1)*per_page).limit(per_page).all()

@router.post("/{vendor_id}/save")
def toggle_save(vendor_id: str, current_user: User=Depends(get_current_user), db: Session=Depends(get_db)):
    ex = db.query(SavedVendor).filter(SavedVendor.user_id==current_user.id, SavedVendor.vendor_id==vendor_id).first()
    if ex: db.delete(ex); db.commit(); return {"saved": False}
    db.add(SavedVendor(user_id=current_user.id, vendor_id=vendor_id)); db.commit(); return {"saved": True}
