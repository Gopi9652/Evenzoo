import uuid, enum
from datetime import datetime
from sqlalchemy import (Column, String, Integer, Float, Boolean,
    DateTime, Date, Text, ForeignKey, Enum, JSON)
from sqlalchemy.orm import relationship
from app.db.session import Base

def gen_uuid(): return str(uuid.uuid4())

class UserRole(str, enum.Enum):
    customer = "customer"; vendor = "vendor"; admin = "admin"

class StateEnum(str, enum.Enum):
    telangana = "Telangana"; andhra_pradesh = "Andhra Pradesh"

class LanguagePref(str, enum.Enum):
    telugu = "Telugu"; english = "English"; hindi = "Hindi"

class CategoryEnum(str, enum.Enum):
    photography = "photography"; videography = "videography"
    decoration = "decoration"; catering = "catering"; dj = "dj"
    bridal_makeup = "bridal_makeup"; venue = "venue"; mehendi = "mehendi"
    tent_mandap = "tent_mandap"; wedding_cars = "wedding_cars"
    custom_cakes = "custom_cakes"; invitation_cards = "invitation_cards"

class BookingStatus(str, enum.Enum):
    pending = "pending"; confirmed = "confirmed"; completed = "completed"
    cancelled = "cancelled"; declined = "declined"

class PaymentStatus(str, enum.Enum):
    unpaid = "unpaid"; advance_paid = "advance_paid"
    full_paid = "full_paid"; released = "released"; refunded = "refunded"

class EventType(str, enum.Enum):
    wedding = "wedding"; engagement = "engagement"; birthday = "birthday"
    graduation = "graduation"; naming_ceremony = "naming_ceremony"
    anniversary = "anniversary"; corporate = "corporate"; other = "other"

class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=gen_uuid)
    name = Column(String(100), nullable=True)
    phone = Column(String(15), unique=True, nullable=False, index=True)
    role = Column(Enum(UserRole), default=UserRole.customer)
    district = Column(String(100), nullable=True)
    state = Column(Enum(StateEnum), nullable=True)
    language_pref = Column(Enum(LanguagePref), default=LanguagePref.telugu)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    vendor_profile = relationship("VendorProfile", back_populates="user", uselist=False)
    customer_bookings = relationship("Booking", foreign_keys="Booking.customer_id", back_populates="customer")
    saved_vendors = relationship("SavedVendor", back_populates="user")

class OTPStore(Base):
    __tablename__ = "otp_store"
    id = Column(String, primary_key=True, default=gen_uuid)
    phone = Column(String(15), nullable=False, index=True)
    otp = Column(String(6), nullable=False)
    is_used = Column(Boolean, default=False)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class VendorProfile(Base):
    __tablename__ = "vendor_profiles"
    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), unique=True, nullable=False)
    business_name = Column(String(200), nullable=False)
    category = Column(Enum(CategoryEnum), nullable=False)
    description = Column(Text, nullable=True)
    base_price = Column(Integer, nullable=False)
    willing_to_travel = Column(Boolean, default=True)
    travel_radius_km = Column(Integer, default=300)
    travel_charge_per_km = Column(Float, default=12.0)
    quality_score = Column(Float, default=5.0)
    value_score = Column(Float, default=50.0)
    total_events = Column(Integer, default=0)
    portfolio_urls = Column(JSON, default=list)
    verified = Column(Boolean, default=False)
    lat = Column(Float, nullable=True)
    lng = Column(Float, nullable=True)
    district = Column(String(100), nullable=True)
    state = Column(Enum(StateEnum), nullable=True)
    whatsapp_number = Column(String(15), nullable=True)
    instagram_handle = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user = relationship("User", back_populates="vendor_profile")
    availability = relationship("VendorAvailability", back_populates="vendor", cascade="all, delete-orphan")
    bookings = relationship("Booking", foreign_keys="Booking.vendor_id", back_populates="vendor")
    reviews = relationship("Review", back_populates="vendor")

class VendorAvailability(Base):
    __tablename__ = "vendor_availability"
    id = Column(String, primary_key=True, default=gen_uuid)
    vendor_id = Column(String, ForeignKey("vendor_profiles.id"), nullable=False, index=True)
    date = Column(Date, nullable=False, index=True)
    is_available = Column(Boolean, default=True)
    willing_to_travel_on_date = Column(Boolean, default=True)
    vendor = relationship("VendorProfile", back_populates="availability")

class Booking(Base):
    __tablename__ = "bookings"
    id = Column(String, primary_key=True, default=gen_uuid)
    customer_id = Column(String, ForeignKey("users.id"), nullable=False)
    vendor_id = Column(String, ForeignKey("vendor_profiles.id"), nullable=False)
    event_date = Column(Date, nullable=False)
    event_type = Column(Enum(EventType), nullable=False)
    event_location = Column(Text, nullable=False)
    event_start_time = Column(String(10), nullable=True)
    event_duration_hours = Column(Integer, default=6)
    special_requests = Column(Text, nullable=True)
    service_amount = Column(Integer, nullable=False)
    travel_amount = Column(Integer, default=0)
    total_amount = Column(Integer, nullable=False)
    advance_amount = Column(Integer, nullable=False)
    status = Column(Enum(BookingStatus), default=BookingStatus.pending)
    payment_status = Column(Enum(PaymentStatus), default=PaymentStatus.unpaid)
    decline_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    customer = relationship("User", foreign_keys=[customer_id], back_populates="customer_bookings")
    vendor = relationship("VendorProfile", foreign_keys=[vendor_id], back_populates="bookings")
    payment = relationship("Payment", back_populates="booking", uselist=False)
    review = relationship("Review", back_populates="booking", uselist=False)

class Payment(Base):
    __tablename__ = "payments"
    id = Column(String, primary_key=True, default=gen_uuid)
    booking_id = Column(String, ForeignKey("bookings.id"), unique=True, nullable=False)
    razorpay_order_id = Column(String(100), nullable=True)
    razorpay_payment_id = Column(String(100), nullable=True)
    amount = Column(Integer, nullable=False)
    payment_type = Column(String(20), default="advance")
    status = Column(String(20), default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    booking = relationship("Booking", back_populates="payment")

class Review(Base):
    __tablename__ = "reviews"
    id = Column(String, primary_key=True, default=gen_uuid)
    booking_id = Column(String, ForeignKey("bookings.id"), unique=True, nullable=False)
    vendor_id = Column(String, ForeignKey("vendor_profiles.id"), nullable=False)
    customer_id = Column(String, ForeignKey("users.id"), nullable=False)
    rating = Column(Float, nullable=False)
    quality_rating = Column(Float, nullable=True)
    value_rating = Column(Float, nullable=True)
    comment = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    booking = relationship("Booking", back_populates="review")
    vendor = relationship("VendorProfile", back_populates="reviews")

class SavedVendor(Base):
    __tablename__ = "saved_vendors"
    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    vendor_id = Column(String, ForeignKey("vendor_profiles.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="saved_vendors")
