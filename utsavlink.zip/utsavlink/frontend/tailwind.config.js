/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{html,ts}'],
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT:'#C9810A', light:'#F5B731', dark:'#8B5A07' },
        'dark-bg': '#1A1208',
        'dark-2': '#2D2416',
        cream: { DEFAULT:'#F5F0E8', dark:'#E2D9C8' },
        ap: '#1E7A4A',
        ts: '#7B2D8B',
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans','sans-serif'],
        display: ['Fraunces','serif'],
      }
    }
  },
  plugins: []
}
