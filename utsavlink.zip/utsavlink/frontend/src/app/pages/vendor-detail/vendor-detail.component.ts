import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { VendorService } from '../../services/vendor.service';
import { AuthService } from '../../services/auth.service';
import { ToastService } from '../../services/toast.service';
import { ValueBarComponent } from '../../components/common/value-bar/value-bar.component';
import { StarRatingComponent } from '../../components/common/star-rating/star-rating.component';
import { SpinnerComponent } from '../../components/common/spinner/spinner.component';
import { formatCurrency } from '../../models';

@Component({
  selector: 'app-vendor-detail',
  standalone: true,
  imports: [CommonModule, ValueBarComponent, StarRatingComponent, SpinnerComponent],
  templateUrl: './vendor-detail.component.html',
  styleUrl: './vendor-detail.component.css'
})
export class VendorDetailComponent implements OnInit {
  route         = inject(ActivatedRoute);
  router        = inject(Router);
  vendorService = inject(VendorService);
  auth          = inject(AuthService);
  toast         = inject(ToastService);

  vendor:    any    = null;
  reviews:   any[]  = [];
  loading    = true;
  saved      = false;
  activeTab  = 'about';
  tabs       = ['about','pricing','reviews'];

  get isAP() { return this.vendor?.state === 'Andhra Pradesh'; }
  get travelCost() { return 2000; }
  get totalCost() { return (this.vendor?.base_price || 0) + this.travelCost; }
  formatRs(n: number) { return formatCurrency(n); }

  ngOnInit() {
    this.route.params.subscribe(p => {
      const id = p['id'];
      this.vendorService.getVendor(id).subscribe({
        next: v => { this.vendor = v; this.loading = false; },
        error: () => this.loading = false
      });
      this.vendorService.getReviews(id).subscribe({
        next: r => this.reviews = r,
        error: () => {}
      });
    });
  }

  toggleSave() {
    if (!this.auth.isAuthenticated) { this.toast.error('Please login to save vendors'); this.router.navigate(['/login']); return; }
    const id = this.route.snapshot.params['id'];
    this.vendorService.toggleSave(id).subscribe({
      next: (r: any) => { this.saved = r.saved; this.toast.success(r.saved ? 'Vendor saved! ❤️' : 'Removed from saved'); }
    });
  }

  bookNow() {
    if (!this.auth.isAuthenticated) { this.router.navigate(['/login']); return; }
    this.router.navigate(['/booking', this.route.snapshot.params['id']]);
  }

  goBack() { this.router.navigate([-1]); }
}
