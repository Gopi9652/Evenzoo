import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  auth   = inject(AuthService);
  router = inject(Router);
  toast  = inject(ToastService);

  menuItems = [
    { icon: '📋', label: 'My Bookings',       route: '/my-bookings',       show: true          },
    { icon: '🏪', label: 'Vendor Dashboard',  route: '/vendor-dashboard',  show: false /* isVendor */ },
    { icon: '🏪', label: 'Become a Vendor',   route: '/vendor-register',   show: false /* !isVendor */ },
  ];

  get isVendor() { return this.auth.isVendor; }
  get user() { return this.auth.currentUser(); }

  navigate(route: string) { this.router.navigate([route]); }

  logout() {
    this.auth.logout();
    this.toast.success('Logged out successfully');
  }
}
