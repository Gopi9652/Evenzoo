import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { SearchFormComponent } from '../../components/search/search-form/search-form.component';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [CommonModule, SearchFormComponent],
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent implements OnInit {
  queryParams: any = {};
  constructor(private route: ActivatedRoute) {}
  ngOnInit() { this.route.queryParams.subscribe(p => this.queryParams = { ...p }); }
}
