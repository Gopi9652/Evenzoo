import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchService } from '../../services/search.service';
import { VendorSearchResult, formatCurrency } from '../../models';
import { VendorCardComponent } from '../../components/common/vendor-card/vendor-card.component';
import { SavingsBannerComponent } from '../../components/common/savings-banner/savings-banner.component';
import { SpinnerComponent } from '../../components/common/spinner/spinner.component';

@Component({
  selector: 'app-results',
  standalone: true,
  imports: [CommonModule, VendorCardComponent, SavingsBannerComponent, SpinnerComponent],
  templateUrl: './results.component.html',
  styleUrl: './results.component.css'
})
export class ResultsComponent implements OnInit {
  route         = inject(ActivatedRoute);
  router        = inject(Router);
  searchService = inject(SearchService);

  vendors:      VendorSearchResult[] = [];
  loading       = true;
  params:       any = {};
  activeFilter  = 'all';

  filterOptions = [
    { val: 'all', label: 'All'    },
    { val: 'ap',  label: 'AP'     },
    { val: 'ts',  label: 'TS Local' },
  ];

  get filtered(): VendorSearchResult[] {
    if (this.activeFilter === 'ap') return this.vendors.filter(v => v.state === 'Andhra Pradesh');
    if (this.activeFilter === 'ts') return this.vendors.filter(v => v.state === 'Telangana');
    return this.vendors;
  }

  get maxSaving(): number {
    if (!this.vendors.length) return 0;
    return Math.max(...this.vendors.map(v => v.travel_cost || 0));
  }

  get categoryLabel(): string {
    return this.params['category'] ? this.params['category'].replace('_',' ') : '';
  }

  formatRs(n: number) { return formatCurrency(n); }
  setFilter(val: string) { this.activeFilter = val; }
  editSearch() { this.router.navigate(['/search'], { queryParams: this.params }); }

  ngOnInit() {
    this.route.queryParams.subscribe(p => {
      this.params  = p;
      this.loading = true;
      this.searchService.searchVendors(p).subscribe({
        next:  data => { this.vendors = data; this.loading = false; },
        error: ()   => { this.loading = false; }
      });
    });
  }
}
