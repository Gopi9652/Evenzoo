import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { SearchFormComponent } from '../../components/search/search-form/search-form.component';
import { CATEGORIES } from '../../models';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, SearchFormComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  auth = inject(AuthService);
  router = inject(Router);
  categories = CATEGORIES;

  howItWorks = [
    { n:'1', icon:'💰', title:'Enter Budget',     desc:'Tell us your budget and service type' },
    { n:'2', icon:'🔍', title:'Compare Value',    desc:'See TS vs AP vendors ranked by value score' },
    { n:'3', icon:'📅', title:'Book Vendor',      desc:'Check availability, book in 3 easy steps' },
    { n:'4', icon:'🎉', title:'Enjoy Your Event', desc:'Pay securely via UPI. Vendor delivers. You celebrate.' },
  ];

  goToCategory(cat: string) {
    const district = this.auth.currentUser()?.district || 'Nalgonda';
    this.router.navigate(['/results'], {
      queryParams: { category: cat, district, budget: 50000, scope: 'both' }
    });
  }
}
