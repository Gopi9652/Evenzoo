import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { BookingService } from '../../services/booking.service';
import { VendorService } from '../../services/vendor.service';
import { ToastService } from '../../services/toast.service';
import { BookingRequestCardComponent } from '../../components/dashboard/booking-request-card/booking-request-card.component';
import { SpinnerComponent } from '../../components/common/spinner/spinner.component';
import { formatCurrency } from '../../models';

@Component({
  selector: 'app-vendor-dashboard',
  standalone: true,
  imports: [CommonModule, BookingRequestCardComponent, SpinnerComponent],
  templateUrl: './vendor-dashboard.component.html',
  styleUrl: './vendor-dashboard.component.css'
})
export class VendorDashboardComponent implements OnInit {
  bookingService = inject(BookingService);
  vendorService  = inject(VendorService);
  toast          = inject(ToastService);
  router         = inject(Router);

  bookings:  any[] = [];
  vendor:    any   = null;
  loading    = true;
  activeTab  = 'requests';

  tabs = [
    { val: 'requests', label: 'Requests'  },
    { val: 'upcoming', label: 'Upcoming'  },
    { val: 'history',  label: 'History'   },
  ];

  get pending()   { return this.bookings.filter(b => b.status === 'pending'); }
  get confirmed() { return this.bookings.filter(b => b.status === 'confirmed'); }
  get completed() { return this.bookings.filter(b => b.status === 'completed'); }
  get totalEarnings() { return this.completed.reduce((s, b) => s + b.total_amount, 0); }

  formatRs(n: number) { return formatCurrency(n); }

  ngOnInit() { this.loadData(); }

  loadData() {
    this.loading = true;
    this.bookingService.getVendorBookings().subscribe({
      next:  b  => { this.bookings = b; this.loading = false; },
      error: () => { this.loading = false; }
    });
    this.vendorService.getMyProfile().subscribe({
      next: v => this.vendor = v, error: () => {}
    });
  }

  onBookingUpdated() { this.loadData(); }
}
