import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { VendorService } from '../../services/vendor.service';
import { ToastService } from '../../services/toast.service';
import { SpinnerComponent } from '../../components/common/spinner/spinner.component';
import { CATEGORIES, DISTRICTS_TS, DISTRICTS_AP } from '../../models';

@Component({
  selector: 'app-vendor-register',
  standalone: true,
  imports: [CommonModule, FormsModule, SpinnerComponent],
  templateUrl: './vendor-register.component.html',
  styleUrl: './vendor-register.component.css'
})
export class VendorRegisterComponent {
  vendorService = inject(VendorService);
  toast         = inject(ToastService);
  router        = inject(Router);

  loading    = false;
  categories = CATEGORIES;
  districtsTS = DISTRICTS_TS;
  districtsAP = DISTRICTS_AP;

  form = {
    business_name:       '',
    category:            'photography',
    description:         '',
    base_price:          0,
    willing_to_travel:   true,
    travel_radius_km:    300,
    travel_charge_per_km: 12,
    state:               'Andhra Pradesh',
    district:            '',
    whatsapp_number:     '',
    instagram_handle:    '',
  };

  get districts() {
    return this.form.state === 'Telangana' ? this.districtsTS : this.districtsAP;
  }

  onStateChange() { this.form.district = ''; }

  submit() {
    if (!this.form.business_name || !this.form.district || !this.form.base_price) {
      this.toast.error('Please fill all required fields');
      return;
    }
    this.loading = true;
    this.vendorService.registerVendor({
      ...this.form,
      base_price:        Number(this.form.base_price),
      travel_radius_km:  Number(this.form.travel_radius_km),
    }).subscribe({
      next:  () => { this.toast.success('Vendor profile created! 🎉'); this.router.navigate(['/vendor-dashboard']); this.loading = false; },
      error: (e: any) => { this.toast.error(e.error?.detail || 'Registration failed'); this.loading = false; }
    });
  }
}
