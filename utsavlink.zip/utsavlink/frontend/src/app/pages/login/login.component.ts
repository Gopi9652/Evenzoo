import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastService } from '../../services/toast.service';
import { OtpInputComponent } from '../../components/auth/otp-input/otp-input.component';
import { SpinnerComponent } from '../../components/common/spinner/spinner.component';
import { DISTRICTS_TS, DISTRICTS_AP } from '../../models';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, OtpInputComponent, SpinnerComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  auth    = inject(AuthService);
  toast   = inject(ToastService);
  router  = inject(Router);

  step: 'phone'|'otp'|'register' = 'phone';
  phone   = '';
  role    = 'customer';
  loading = false;
  timer   = 0;

  regForm = { name: '', state: 'Telangana', district: '' };
  districtsTS = DISTRICTS_TS;
  districtsAP = DISTRICTS_AP;

  get districts() {
    return this.regForm.state === 'Telangana' ? this.districtsTS : this.districtsAP;
  }

  startTimer() {
    this.timer = 60;
    const t = setInterval(() => {
      this.timer--;
      if (this.timer <= 0) clearInterval(t);
    }, 1000);
  }

  sendOTP() {
    if (this.phone.length !== 10) { this.toast.error('Enter 10-digit phone number'); return; }
    this.loading = true;
    this.auth.sendOTP(this.phone).subscribe({
      next: () => { this.toast.success('OTP sent to +91 ' + this.phone); this.step = 'otp'; this.startTimer(); this.loading = false; },
      error: () => { this.toast.error('Failed to send OTP. Try again.'); this.loading = false; }
    });
  }

  resendOTP() {
    this.auth.sendOTP(this.phone).subscribe({
      next: () => { this.toast.success('OTP resent!'); this.startTimer(); }
    });
  }

  onOtpComplete(otp: string) {
    this.loading = true;
    this.auth.verifyOTP(this.phone, otp).subscribe({
      next: (res: any) => {
        if (res.is_new_user) { this.step = 'register'; this.loading = false; return; }
        this.auth.getMe().subscribe({
          next: () => { this.toast.success('Welcome back!'); this.router.navigate(['/']); this.loading = false; }
        });
      },
      error: () => { this.toast.error('Invalid OTP. Try again.'); this.loading = false; }
    });
  }

  register() {
    if (!this.regForm.name || !this.regForm.district) { this.toast.error('Fill all fields'); return; }
    this.loading = true;
    this.auth.register({ phone: this.phone, ...this.regForm, role: this.role }).subscribe({
      next: () => {
        this.auth.getMe().subscribe({
          next: () => {
            this.toast.success('Welcome to UtsavLink! 🎉');
            this.router.navigate([this.role === 'vendor' ? '/vendor-register' : '/']);
            this.loading = false;
          }
        });
      },
      error: () => { this.toast.error('Registration failed'); this.loading = false; }
    });
  }

  toggleRole() { this.role = this.role === 'vendor' ? 'customer' : 'vendor'; }
  goBack() { this.step = 'phone'; }
}
