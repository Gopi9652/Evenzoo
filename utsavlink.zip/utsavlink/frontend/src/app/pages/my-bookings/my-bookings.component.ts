import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BookingService } from '../../services/booking.service';
import { ToastService } from '../../services/toast.service';
import { SpinnerComponent } from '../../components/common/spinner/spinner.component';
import { formatCurrency } from '../../models';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule, FormsModule, SpinnerComponent],
  templateUrl: './my-bookings.component.html',
  styleUrl: './my-bookings.component.css'
})
export class MyBookingsComponent implements OnInit {
  bookingService = inject(BookingService);
  toast          = inject(ToastService);

  bookings:      any[] = [];
  loading        = true;
  activeTab      = 'active';
  reviewingId    = '';
  review         = { rating: 5, quality_rating: 5, value_rating: 5, comment: '' };
  stars          = [1,2,3,4,5];

  tabs = [
    { val: 'active', label: 'Active'    },
    { val: 'done',   label: 'Completed' },
  ];

  get active() { return this.bookings.filter(b => ['pending','confirmed'].includes(b.status)); }
  get done()   { return this.bookings.filter(b => ['completed','declined','cancelled'].includes(b.status)); }
  get list()   { return this.activeTab === 'active' ? this.active : this.done; }

  formatRs(n: number) { return formatCurrency(n); }

  statusClass(status: string): string {
    const map: Record<string,string> = {
      pending:   'bg-yellow-50 text-yellow-700 border-yellow-200',
      confirmed: 'bg-green-50 text-ap border-green-200',
      completed: 'bg-blue-50 text-blue-700 border-blue-200',
      declined:  'bg-red-50 text-red-600 border-red-200',
      cancelled: 'bg-gray-50 text-gray-500 border-gray-200',
    };
    return map[status] || '';
  }

  ngOnInit() {
    this.bookingService.getMyBookings().subscribe({
      next: b  => { this.bookings = b; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  setReviewRating(field: string, val: number) {
    (this.review as any)[field] = val;
  }

  submitReview(bookingId: string) {
    if (!this.review.comment.trim()) { this.toast.error('Please write a comment'); return; }
    this.bookingService.createReview({ booking_id: bookingId, ...this.review }).subscribe({
      next:  () => { this.toast.success('Review submitted! Thank you 🙏'); this.reviewingId = ''; this.ngOnInit(); },
      error: (e: any) => this.toast.error(e.error?.detail || 'Failed to submit review')
    });
  }
}
