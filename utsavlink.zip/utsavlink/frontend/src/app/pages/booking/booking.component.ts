import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { VendorService } from '../../services/vendor.service';
import { BookingService } from '../../services/booking.service';
import { ToastService } from '../../services/toast.service';
import { BookingCalendarComponent } from '../../components/booking/booking-calendar/booking-calendar.component';
import { BookingSummaryComponent } from '../../components/booking/booking-summary/booking-summary.component';
import { SpinnerComponent } from '../../components/common/spinner/spinner.component';
import { EVENT_TYPES, formatCurrency } from '../../models';

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule, FormsModule, BookingCalendarComponent, BookingSummaryComponent, SpinnerComponent],
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent implements OnInit {
  route          = inject(ActivatedRoute);
  router         = inject(Router);
  vendorService  = inject(VendorService);
  bookingService = inject(BookingService);
  toast          = inject(ToastService);

  vendorId     = '';
  vendor:any   = null;
  step         = 0;
  steps        = ['Date', 'Details', 'Confirm'];
  selectedDate = '';
  bookingId    = '';
  loading      = false;
  eventTypes   = EVENT_TYPES;

  form = {
    event_type:           'wedding',
    event_location:       '',
    event_start_time:     '10:00',
    event_duration_hours: 6,
    special_requests:     '',
  };

  get travelCost()  { return 2000; }
  get total()       { return (this.vendor?.base_price || 0) + this.travelCost; }
  get advance()     { return Math.round(this.total * 0.3); }
  formatRs(n: number) { return formatCurrency(n); }

  ngOnInit() {
    this.vendorId = this.route.snapshot.params['vendorId'];
    this.vendorService.getVendor(this.vendorId).subscribe({
      next: v => this.vendor = v
    });
  }

  onDateSelected(date: string) { this.selectedDate = date; }

  nextStep() {
    if (this.step === 0 && !this.selectedDate) { this.toast.error('Please select an event date'); return; }
    if (this.step === 1 && !this.form.event_location.trim()) { this.toast.error('Please enter the venue address'); return; }
    if (this.step === 1) { this.createBooking(); return; }
    this.step++;
  }

  prevStep() {
    if (this.step > 0) this.step--;
    else this.router.navigate(['/vendor', this.vendorId]);
  }

  createBooking() {
    this.loading = true;
    this.bookingService.createBooking({
      vendor_id:            this.vendorId,
      event_date:           this.selectedDate,
      event_type:           this.form.event_type,
      event_location:       this.form.event_location,
      event_start_time:     this.form.event_start_time,
      event_duration_hours: Number(this.form.event_duration_hours),
      special_requests:     this.form.special_requests || null,
    }).subscribe({
      next: (b: any) => { this.bookingId = b.id; this.step = 2; this.loading = false; },
      error: (e: any) => { this.toast.error(e.error?.detail || 'Booking failed. Try again.'); this.loading = false; }
    });
  }

  pay() {
    this.loading = true;
    this.bookingService.initiatePayment(this.bookingId).subscribe({
      next: (res: any) => {
        if (res.razorpay_key === 'rzp_test_demo') {
          // DEV MODE — simulate payment success
          this.bookingService.verifyPayment({
            razorpay_order_id:   res.order_id,
            razorpay_payment_id: 'pay_dev_' + Date.now(),
            razorpay_signature:  '',
          }).subscribe({
            next: () => { this.toast.success('Payment successful! 🎉'); this.router.navigate(['/my-bookings']); this.loading = false; }
          });
          return;
        }
        // PRODUCTION — open Razorpay modal
        const rzp = new (window as any).Razorpay({
          key:         res.razorpay_key,
          amount:      res.amount * 100,
          currency:    'INR',
          name:        'UtsavLink',
          description: `Advance for ${this.vendor?.business_name}`,
          order_id:    res.order_id,
          handler:     (response: any) => {
            this.bookingService.verifyPayment(response).subscribe({
              next: () => { this.toast.success('Payment successful! 🎉'); this.router.navigate(['/my-bookings']); }
            });
          },
          theme: { color: '#C9810A' }
        });
        rzp.open();
        this.loading = false;
      },
      error: () => { this.toast.error('Payment initialization failed'); this.loading = false; }
    });
  }
}
