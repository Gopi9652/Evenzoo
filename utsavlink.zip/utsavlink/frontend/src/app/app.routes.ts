import { Routes } from '@angular/router';
import { authGuard, vendorGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', loadComponent: () => import('./pages/home/home.component').then(m=>m.HomeComponent) },
  { path: 'login', loadComponent: () => import('./pages/login/login.component').then(m=>m.LoginComponent) },
  { path: 'search', loadComponent: () => import('./pages/search/search.component').then(m=>m.SearchComponent) },
  { path: 'results', loadComponent: () => import('./pages/results/results.component').then(m=>m.ResultsComponent) },
  { path: 'vendor/:id', loadComponent: () => import('./pages/vendor-detail/vendor-detail.component').then(m=>m.VendorDetailComponent) },
  { path: 'booking/:vendorId', loadComponent: () => import('./pages/booking/booking.component').then(m=>m.BookingComponent), canActivate:[authGuard] },
  { path: 'my-bookings', loadComponent: () => import('./pages/my-bookings/my-bookings.component').then(m=>m.MyBookingsComponent), canActivate:[authGuard] },
  { path: 'profile', loadComponent: () => import('./pages/profile/profile.component').then(m=>m.ProfileComponent), canActivate:[authGuard] },
  { path: 'vendor-register', loadComponent: () => import('./pages/vendor-register/vendor-register.component').then(m=>m.VendorRegisterComponent), canActivate:[authGuard] },
  { path: 'vendor-dashboard', loadComponent: () => import('./pages/vendor-dashboard/vendor-dashboard.component').then(m=>m.VendorDashboardComponent), canActivate:[vendorGuard] },
  { path: '**', redirectTo: '' }
];
