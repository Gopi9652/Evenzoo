export interface User {
  id: string; name: string; phone: string;
  role: 'customer'|'vendor'|'admin';
  district: string; state: 'Telangana'|'Andhra Pradesh';
  language_pref: string;
}
export interface VendorProfile {
  id: string; user_id: string; business_name: string; category: string;
  description: string; base_price: number; willing_to_travel: boolean;
  travel_radius_km: number; quality_score: number; value_score: number;
  total_events: number; portfolio_urls: string[]; verified: boolean;
  district: string; state: string; whatsapp_number: string; instagram_handle: string;
}
export interface VendorSearchResult {
  id: string; business_name: string; category: string;
  district: string; state: string; base_price: number;
  travel_cost: number; total_cost: number; value_score: number;
  quality_score: number; avg_rating: number|null; total_reviews: number;
  total_events: number; portfolio_urls: string[]; verified: boolean;
  willing_to_travel: boolean; distance_km: number|null;
}
export interface Booking {
  id: string; customer_id: string; vendor_id: string;
  event_date: string; event_type: string; event_location: string;
  event_start_time: string; event_duration_hours: number;
  special_requests: string; service_amount: number;
  travel_amount: number; total_amount: number; advance_amount: number;
  status: 'pending'|'confirmed'|'completed'|'cancelled'|'declined';
  payment_status: 'unpaid'|'advance_paid'|'full_paid'|'released';
  decline_reason?: string; created_at: string;
}
export interface Review {
  id: string; booking_id: string; vendor_id: string;
  rating: number; quality_rating: number; value_rating: number;
  comment: string; created_at: string;
}
export const CATEGORIES = [
  {value:'photography',label:'Photography',icon:'📸'},
  {value:'videography',label:'Videography',icon:'🎬'},
  {value:'decoration',label:'Decoration',icon:'🌸'},
  {value:'catering',label:'Catering',icon:'🍽️'},
  {value:'dj',label:'DJ & Music',icon:'🎤'},
  {value:'bridal_makeup',label:'Bridal Makeup',icon:'💄'},
  {value:'venue',label:'Venue',icon:'🏟️'},
  {value:'mehendi',label:'Mehendi',icon:'🪔'},
  {value:'tent_mandap',label:'Tent & Mandap',icon:'🎪'},
  {value:'wedding_cars',label:'Wedding Cars',icon:'🚗'},
  {value:'custom_cakes',label:'Custom Cakes',icon:'🎂'},
  {value:'invitation_cards',label:'Invitation Cards',icon:'🎁'},
];
export const EVENT_TYPES = [
  {value:'wedding',label:'💒 Wedding'},
  {value:'engagement',label:'💍 Engagement'},
  {value:'birthday',label:'🎂 Birthday'},
  {value:'graduation',label:'🎓 Graduation'},
  {value:'naming_ceremony',label:'🪔 Naming Ceremony'},
  {value:'anniversary',label:'💑 Anniversary'},
  {value:'corporate',label:'🏢 Corporate'},
  {value:'other',label:'📅 Other'},
];
export const DISTRICTS_TS = ['Hyderabad','Rangareddy','Medak','Nizamabad','Karimnagar','Warangal','Khammam','Nalgonda','Mahabubnagar','Adilabad'];
export const DISTRICTS_AP = ['Vijayawada','Guntur','Visakhapatnam','Nellore','Kurnool','Tirupati','Rajahmundry','Kakinada','Anantapur','Kadapa'];
export const QUICK_BUDGETS = [15000,25000,30000,50000,75000,100000];
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(amount);
}
export function getCategoryIcon(cat: string): string {
  return CATEGORIES.find(c=>c.value===cat)?.icon || '🎪';
}
