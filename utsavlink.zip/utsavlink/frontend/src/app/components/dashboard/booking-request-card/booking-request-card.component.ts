import { Component, Input, Output, EventEmitter, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BookingService } from '../../../services/booking.service';
import { ToastService } from '../../../services/toast.service';
import { formatCurrency } from '../../../models';

@Component({
  selector: 'app-booking-request-card',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './booking-request-card.component.html',
  styleUrl: './booking-request-card.component.css'
})
export class BookingRequestCardComponent {
  @Input() booking: any;
  @Output() updated = new EventEmitter<void>();

  bookingService = inject(BookingService);
  toast = inject(ToastService);

  loading = false;
  showDeclineForm = false;
  declineReason = '';

  formatRs(n: number) { return formatCurrency(n); }

  accept() {
    this.loading = true;
    this.bookingService.confirmBooking(this.booking.id).subscribe({
      next: () => { this.toast.success('Booking confirmed! ✓'); this.updated.emit(); this.loading = false; },
      error: () => { this.toast.error('Failed to confirm'); this.loading = false; }
    });
  }

  submitDecline() {
    if (!this.declineReason.trim()) { this.toast.error('Please enter a reason'); return; }
    this.loading = true;
    this.bookingService.declineBooking(this.booking.id, this.declineReason).subscribe({
      next: () => { this.toast.success('Booking declined'); this.updated.emit(); this.loading = false; },
      error: () => { this.toast.error('Failed to decline'); this.loading = false; }
    });
  }
}
