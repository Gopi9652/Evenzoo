import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-spinner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './spinner.component.html',
  styleUrl: './spinner.component.css'
})
export class SpinnerComponent {
  @Input() size: 'sm'|'md'|'lg' = 'md';
  get cls() {
    return this.size === 'sm' ? 'h-4 w-4 border-2'
         : this.size === 'lg' ? 'h-10 w-10 border-4'
         : 'h-6 w-6 border-2';
  }
}
