import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../../../services/toast.service';

@Component({
  selector: 'app-toast',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './toast.component.html',
  styleUrl: './toast.component.css'
})
export class ToastComponent {
  toastService = inject(ToastService);

  getWrapperClass(type: string): string {
    const base = 'toast-item flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold shadow-lg border-l-4';
    if (type === 'success') return `${base} bg-dark-bg text-white border-ap`;
    if (type === 'error')   return `${base} bg-dark-bg text-white border-red-500`;
    return `${base} bg-dark-bg text-white border-gold`;
  }

  getIcon(type: string): string {
    if (type === 'success') return '✅';
    if (type === 'error')   return '❌';
    return 'ℹ️';
  }
}
