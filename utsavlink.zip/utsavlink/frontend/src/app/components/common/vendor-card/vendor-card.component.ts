import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { VendorSearchResult, formatCurrency, getCategoryIcon } from '../../../models';
import { ValueBarComponent } from '../value-bar/value-bar.component';
import { StarRatingComponent } from '../star-rating/star-rating.component';

@Component({
  selector: 'app-vendor-card',
  standalone: true,
  imports: [CommonModule, ValueBarComponent, StarRatingComponent],
  templateUrl: './vendor-card.component.html',
  styleUrl: './vendor-card.component.css'
})
export class VendorCardComponent {
  @Input() vendor!: VendorSearchResult;
  @Input() isBestValue: boolean = false;

  constructor(private router: Router) {}

  get isAP() { return this.vendor.state === 'Andhra Pradesh'; }
  get categoryIcon() { return getCategoryIcon(this.vendor.category); }
  formatRs(n: number) { return formatCurrency(n); }
  goToVendor() { this.router.navigate(['/vendor', this.vendor.id]); }
}
