import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-value-bar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './value-bar.component.html',
  styleUrl: './value-bar.component.css'
})
export class ValueBarComponent {
  @Input() score: number = 0;

  get barColor(): string {
    if (this.score >= 80) return 'bg-ap';
    if (this.score >= 60) return 'bg-gold';
    return 'bg-red-400';
  }

  get labelColor(): string {
    if (this.score >= 80) return 'text-ap';
    if (this.score >= 60) return 'text-gold';
    return 'text-red-500';
  }
}
