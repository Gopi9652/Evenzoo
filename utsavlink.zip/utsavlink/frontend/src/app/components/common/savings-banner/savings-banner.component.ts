import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { formatCurrency } from '../../../models';

@Component({
  selector: 'app-savings-banner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './savings-banner.component.html',
  styleUrl: './savings-banner.component.css'
})
export class SavingsBannerComponent {
  @Input() saving: number = 0;
  @Input() district: string = '';
  formatRs(n: number) { return formatCurrency(n); }
}
