import { Component, Input, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CATEGORIES, DISTRICTS_TS, DISTRICTS_AP, QUICK_BUDGETS } from '../../../models';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-search-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './search-form.component.html',
  styleUrl: './search-form.component.css'
})
export class SearchFormComponent implements OnInit {
  @Input() initialValues: any = {};

  auth = inject(AuthService);
  router = inject(Router);

  categories = CATEGORIES;
  quickBudgets = QUICK_BUDGETS;
  districtsTS = DISTRICTS_TS;
  districtsAP = DISTRICTS_AP;
  today = new Date().toISOString().split('T')[0];

  scopeOptions = [
    { val: 'both',  label: 'TS + AP'    },
    { val: 'local', label: 'Local Only' },
    { val: 'cross', label: 'AP Only'    },
  ];

  form = { category: '', budget: 0, district: '', event_date: '', scope: 'both' };

  ngOnInit() {
    this.form = {
      category:   this.initialValues['category']   || '',
      budget:     this.initialValues['budget']     || 0,
      district:   this.initialValues['district']   || this.auth.currentUser()?.district || '',
      event_date: this.initialValues['event_date'] || '',
      scope:      this.initialValues['scope']      || 'both',
    };
  }

  setQuickBudget(amount: number) { this.form.budget = amount; }
  setScope(val: string) { this.form.scope = val; }

  onSubmit() {
    if (!this.form.category || !this.form.budget || !this.form.district) return;
    const qp: any = {
      category: this.form.category,
      budget:   this.form.budget,
      district: this.form.district,
      scope:    this.form.scope,
    };
    if (this.form.event_date) qp['event_date'] = this.form.event_date;
    this.router.navigate(['/results'], { queryParams: qp });
  }
}
