import { Component, Output, EventEmitter, ViewChildren, QueryList, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-otp-input',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './otp-input.component.html',
  styleUrl: './otp-input.component.css'
})
export class OtpInputComponent {
  @Output() otpComplete = new EventEmitter<string>();
  @ViewChildren('otpBox') boxes!: QueryList<ElementRef>;

  digits: string[] = ['','','','','',''];
  indices = [0,1,2,3,4,5];

  onInput(index: number, event: Event) {
    const val = (event.target as HTMLInputElement).value.replace(/\D/g,'');
    if (!val) return;
    this.digits[index] = val.slice(-1);
    const otp = this.digits.join('');
    if (otp.length === 6) this.otpComplete.emit(otp);
    if (index < 5) {
      const els = this.boxes.toArray();
      els[index + 1]?.nativeElement.focus();
    }
  }

  onKeydown(index: number, event: KeyboardEvent) {
    if (event.key === 'Backspace') {
      this.digits[index] = '';
      if (index > 0) {
        const els = this.boxes.toArray();
        els[index - 1]?.nativeElement.focus();
      }
    }
  }

  reset() { this.digits = ['','','','','','']; }
}
