import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { formatCurrency } from '../../../models';

@Component({
  selector: 'app-booking-summary',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './booking-summary.component.html',
  styleUrl: './booking-summary.component.css'
})
export class BookingSummaryComponent {
  @Input() vendor: any;
  @Input() date: string = '';
  @Input() total: number = 0;
  @Input() advance: number = 0;
  @Input() travelCost: number = 0;

  get balance() { return this.total - this.advance; }
  get isAP() { return this.vendor?.state === 'Andhra Pradesh'; }
  formatRs(n: number) { return formatCurrency(n); }
}
