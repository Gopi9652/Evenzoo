import { Component, Input, Output, EventEmitter, OnInit, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VendorService } from '../../../services/vendor.service';

@Component({
  selector: 'app-booking-calendar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './booking-calendar.component.html',
  styleUrl: './booking-calendar.component.css'
})
export class BookingCalendarComponent implements OnInit, OnChanges {
  @Input() vendorId!: string;
  @Input() selectedDate: string = '';
  @Output() dateSelected = new EventEmitter<string>();

  dayNames   = ['Su','Mo','Tu','We','Th','Fr','Sa'];
  blanks:   number[] = [];
  days:     number[] = [];
  availability: any[] = [];

  currentYear  = new Date().getFullYear();
  currentMonth = new Date().getMonth();

  constructor(private vendorService: VendorService) {}

  ngOnInit()    { this.build(); this.load(); }
  ngOnChanges() { this.build(); }

  get monthLabel() {
    return new Date(this.currentYear, this.currentMonth)
      .toLocaleDateString('en-IN', { month:'long', year:'numeric' });
  }

  build() {
    const first = new Date(this.currentYear, this.currentMonth, 1);
    const total = new Date(this.currentYear, this.currentMonth+1, 0).getDate();
    this.blanks = Array(first.getDay()).fill(0);
    this.days   = Array.from({ length: total }, (_, i) => i+1);
  }

  load() {
    const month = `${this.currentYear}-${String(this.currentMonth+1).padStart(2,'0')}`;
    this.vendorService.getAvailability(this.vendorId, month).subscribe({
      next: data => this.availability = data,
      error: ()  => {}
    });
  }

  dateStr(day: number) {
    return `${this.currentYear}-${String(this.currentMonth+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
  }

  status(day: number): 'booked'|'available'|'unknown' {
    const ds  = this.dateStr(day);
    const rec = this.availability.find(a => a.date === ds);
    if (rec && !rec.is_available) return 'booked';
    if (rec &&  rec.is_available) return 'available';
    return 'unknown';
  }

  isPast(day: number): boolean {
    const today = new Date(); today.setHours(0,0,0,0);
    return new Date(this.dateStr(day)) < today;
  }

  dayClass(day: number): string {
    const ds = this.dateStr(day);
    if (this.selectedDate === ds)       return 'day-selected';
    if (this.isPast(day))               return 'day-past';
    if (this.status(day) === 'booked')  return 'day-booked';
    if (this.status(day) === 'available') return 'day-available';
    return 'day-default';
  }

  select(day: number) {
    if (this.isPast(day) || this.status(day) === 'booked') return;
    this.dateSelected.emit(this.dateStr(day));
  }

  prev() {
    if (this.currentMonth === 0) { this.currentMonth=11; this.currentYear--; }
    else this.currentMonth--;
    this.build(); this.load();
  }
  next() {
    if (this.currentMonth === 11) { this.currentMonth=0; this.currentYear++; }
    else this.currentMonth++;
    this.build(); this.load();
  }
}
