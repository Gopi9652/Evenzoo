import { Injectable, signal } from '@angular/core';
export interface Toast { id: number; message: string; type: 'success'|'error'|'info'; }

@Injectable({ providedIn: 'root' })
export class ToastService {
  toasts = signal<Toast[]>([]);
  private n = 0;
  private add(message: string, type: Toast['type']) {
    const id = ++this.n;
    this.toasts.update(t => [...t, { id, message, type }]);
    setTimeout(() => this.toasts.update(t => t.filter(x => x.id !== id)), 3500);
  }
  success(msg: string) { this.add(msg, 'success'); }
  error(msg: string) { this.add(msg, 'error'); }
  info(msg: string) { this.add(msg, 'info'); }
  remove(id: number) { this.toasts.update(t => t.filter(x => x.id !== id)); }
}
