import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class BookingService {
  private api = environment.apiUrl + '/api/v1';
  constructor(private http: HttpClient) {}
  createBooking(data: any): Observable<any> { return this.http.post(`${this.api}/bookings`, data); }
  getMyBookings(): Observable<any[]> { return this.http.get<any[]>(`${this.api}/bookings/my`); }
  confirmBooking(id: string): Observable<any> { return this.http.put(`${this.api}/bookings/${id}/confirm`, {}); }
  declineBooking(id: string, reason: string): Observable<any> { return this.http.put(`${this.api}/bookings/${id}/decline`, { reason }); }
  completeBooking(id: string): Observable<any> { return this.http.put(`${this.api}/bookings/${id}/complete`, {}); }
  getVendorBookings(): Observable<any[]> { return this.http.get<any[]>(`${this.api}/vendor/bookings`); }
  initiatePayment(booking_id: string): Observable<any> { return this.http.post(`${this.api}/payments/initiate`, { booking_id }); }
  verifyPayment(data: any): Observable<any> { return this.http.post(`${this.api}/payments/verify`, data); }
  createReview(data: any): Observable<any> { return this.http.post(`${this.api}/reviews`, data); }
}
