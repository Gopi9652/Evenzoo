import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class VendorService {
  private api = environment.apiUrl + '/api/v1';
  constructor(private http: HttpClient) {}
  getVendor(id: string): Observable<any> { return this.http.get(`${this.api}/vendors/${id}`); }
  registerVendor(data: any): Observable<any> { return this.http.post(`${this.api}/vendors/register`, data); }
  updateVendor(id: string, data: any): Observable<any> { return this.http.put(`${this.api}/vendors/${id}`, data); }
  getAvailability(id: string, month: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.api}/vendors/${id}/availability`, { params: new HttpParams().set('month', month) });
  }
  setAvailability(id: string, dates: any[]): Observable<any> {
    return this.http.post(`${this.api}/vendors/${id}/availability`, { dates });
  }
  getReviews(id: string, page=1): Observable<any[]> {
    return this.http.get<any[]>(`${this.api}/vendors/${id}/reviews`, { params: new HttpParams().set('page', page) });
  }
  toggleSave(id: string): Observable<any> { return this.http.post(`${this.api}/vendors/${id}/save`, {}); }
  getSavedList(): Observable<any[]> { return this.http.get<any[]>(`${this.api}/vendors/saved/list`); }
  getMyProfile(): Observable<any> { return this.http.get(`${this.api}/vendors/me/profile`); }
}
