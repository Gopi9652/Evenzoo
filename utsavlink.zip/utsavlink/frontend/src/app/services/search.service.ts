import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class SearchService {
  private api = environment.apiUrl + '/api/v1/search';
  constructor(private http: HttpClient) {}
  searchVendors(params: any): Observable<any[]> {
    let p = new HttpParams();
    Object.keys(params).forEach(k => { if (params[k]) p = p.set(k, params[k]); });
    return this.http.get<any[]>(`${this.api}/vendors`, { params: p });
  }
  searchBundles(params: any): Observable<any[]> {
    let p = new HttpParams();
    Object.keys(params).forEach(k => { if (params[k]) p = p.set(k, params[k]); });
    return this.http.get<any[]>(`${this.api}/bundles`, { params: p });
  }
}
