import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { User } from '../models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = environment.apiUrl + '/api/v1/auth';
  currentUser = signal<User|null>(this.loadUser());
  token = signal<string|null>(localStorage.getItem('token'));

  constructor(private http: HttpClient, private router: Router) {}

  get isAuthenticated() { return !!this.token(); }
  get isVendor() { return this.currentUser()?.role === 'vendor'; }

  private loadUser(): User|null {
    const u = localStorage.getItem('user');
    return u ? JSON.parse(u) : null;
  }

  sendOTP(phone: string): Observable<any> {
    return this.http.post(`${this.api}/send-otp`, { phone });
  }
  verifyOTP(phone: string, otp: string): Observable<any> {
    return this.http.post(`${this.api}/verify-otp`, { phone, otp }).pipe(
      tap((r: any) => { localStorage.setItem('token', r.access_token); this.token.set(r.access_token); })
    );
  }
  register(data: any): Observable<any> {
    return this.http.post(`${this.api}/register`, data).pipe(
      tap((r: any) => { localStorage.setItem('token', r.access_token); this.token.set(r.access_token); })
    );
  }
  getMe(): Observable<User> {
    return this.http.get<User>(`${this.api}/me`).pipe(
      tap(u => { localStorage.setItem('user', JSON.stringify(u)); this.currentUser.set(u); })
    );
  }
  logout() {
    localStorage.clear();
    this.token.set(null); this.currentUser.set(null);
    this.router.navigate(['/']);
  }
}
