export const environment = {
  production: true,
  apiUrl: 'https://your-api-domain.com',
  razorpayKey: 'rzp_live_xxxxxxxxx'
};
